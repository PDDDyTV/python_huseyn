def classify_char(ch):
    if len(ch) != 1:
        return "Нужно ввести только один символ"
    elif ch.isdigit():
        return "Это цифра."
    elif 'A' <= ch <= 'Z' or 'А' <= ch <= 'Я':
        return "Это БОЛЬШАЯ буква."
    elif 'a' <= ch <= 'z' or 'а' <= ch <= 'я':
        return "Это маленькая буква."
    elif ch == " ":
        return "Это пробел."
    else:
        return "Это другой символ, например знак."


ch = input("введите чтото")
print(classify_char(ch))
